To run the code fore each problem, open and run the script for that problem.  
For example, open P1 in matlab and hit run. 