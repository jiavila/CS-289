To run the code fore each problem, open and run the script for that problem.  
For example, open P1 in matlab and hit run.  The directories at the top of each 
problem are not in reference to a directory, so they'll have to be changed for a
different computer.